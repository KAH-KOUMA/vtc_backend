import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ClientBookingScreen extends StatefulWidget {
  @override
  _ClientBookingScreenState createState() => _ClientBookingScreenState();
}

class _ClientBookingScreenState extends State<ClientBookingScreen> {
  final ApiService _api = ApiService();
  List<dynamic> drivers = [];

  @override
  void initState() {
    super.initState();
    _loadDrivers();
  }

  void _loadDrivers() async {
    try {
      final data = await _api.getAvailableDrivers();
      setState(() {
        drivers = data;
      });
    } catch (e) {
      print('Erreur chargement chauffeurs: $e');
    }
  }

  void _bookRide(String driverId) async {
    try {
      await _api.createBooking(driverId, 'Point A', 'Point B');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Course réservée !')));
    } catch (e) {
      print('Erreur réservation: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Réserver une course')),
      body: ListView.builder(
        itemCount: drivers.length,
        itemBuilder: (context, index) {
          final driver = drivers[index];
          return ListTile(
            title: Text(driver['name']),
            subtitle: Text('Disponible'),
            trailing: ElevatedButton(
              onPressed: () => _bookRide(driver['_id']),
              child: Text('Réserver'),
            ),
          );
        },
      ),
    );
  }
}
