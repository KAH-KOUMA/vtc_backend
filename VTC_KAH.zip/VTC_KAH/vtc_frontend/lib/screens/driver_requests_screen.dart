import 'package:flutter/material.dart';
import '../services/api_service.dart';

class DriverRequestsScreen extends StatefulWidget {
  @override
  _DriverRequestsScreenState createState() => _DriverRequestsScreenState();
}

class _DriverRequestsScreenState extends State<DriverRequestsScreen> {
  final ApiService _api = ApiService();
  List<dynamic> requests = [];

  @override
  void initState() {
    super.initState();
    _loadRequests();
  }

  void _loadRequests() async {
    try {
      final data = await _api.getPendingRequests();
      setState(() {
        requests = data;
      });
    } catch (e) {
      print('Erreur chargement demandes: $e');
    }
  }

  void _acceptRequest(String bookingId) async {
    try {
      await _api.acceptRequest(bookingId);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Course acceptée !')));
      _loadRequests();
    } catch (e) {
      print('Erreur acceptation: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Demandes en attente')),
      body: ListView.builder(
        itemCount: requests.length,
        itemBuilder: (context, index) {
          final req = requests[index];
          return ListTile(
            title: Text('Course ${req['_id']}'),
            subtitle: Text('Client: ${req['clientName']}'),
            trailing: ElevatedButton(
              onPressed: () => _acceptRequest(req['_id']),
              child: Text('Accepter'),
            ),
          );
        },
      ),
    );
  }
}
