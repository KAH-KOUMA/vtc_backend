import 'package:flutter/material.dart';

class DriverDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tableau de bord Chauffeur')),
      body: Center(child: Text('Bienvenue, chauffeur !')),
    );
  }
}
