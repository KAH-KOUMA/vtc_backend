import 'package:flutter/material.dart';
import '../services/secure_storage.dart';
import '../services/auth_service.dart'; // Importer AuthService
import 'client_dashboard.dart';
import 'driver_dashboard.dart';
import 'login_screen.dart';

class AuthWrapper extends StatefulWidget {
  @override
  _AuthWrapperState createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  final SecureStorage _storage = SecureStorage();
  final AuthService _authService = AuthService(); // Instancier AuthService

  String? _role;

  @override
  void initState() {
    super.initState();
    _checkAuth();
  }

  void _checkAuth() async {
    final token = await _storage.getToken();
    if (token != null) {
      try {
        final role = await _authService.getUserRole(token); // Appel réel pour récupérer le rôle
        setState(() {
          _role = role; // "client" ou "driver"
        });
      } catch (e) {
        print('Erreur récupération du rôle : $e');
        setState(() {
          _role = 'unauthenticated'; // En cas d'erreur
        });
      }
    } else {
      setState(() {
        _role = 'unauthenticated'; // Si pas de token
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_role == null) {
      return Center(child: CircularProgressIndicator()); // Chargement
    } else if (_role == 'client') {
      return ClientDashboard(); // Redirection vers le dashboard client
    } else if (_role == 'driver') {
      return DriverDashboard(); // Redirection vers le dashboard chauffeur
    } else {
      return LoginScreen(); // Si non authentifié
    }
  }
}
