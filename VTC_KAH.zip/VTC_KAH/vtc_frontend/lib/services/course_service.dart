import 'dart:convert';
import 'package:http/http.dart';
import 'api_service.dart';

class CourseService {
  final ApiService _api = ApiService();

  /// Récupère toutes les courses avec un token d'authentification
  Future<List<dynamic>> getCourses(String token) async {
    final response = await _api.getRequest('/courses', token);

    if (response.statusCode == 200) {
      try {
        return jsonDecode(response.body);
      } catch (e) {
        throw Exception('Erreur de parsing JSON : $e');
      }
    } else {
      throw Exception('Impossible de récupérer les courses : ${response.body}');
    }
  }

  /// Crée une nouvelle course avec les données fournies et le token
  Future<Map<String, dynamic>> createCourse(Map<String, dynamic> courseData, String token) async {
    final response = await _api.postRequest('/courses', courseData, token);

    if (response.statusCode == 201) {
      try {
        return jsonDecode(response.body);
      } catch (e) {
        throw Exception('Erreur de parsing JSON : $e');
      }
    } else {
      throw Exception('Impossible de créer la course : ${response.body}');
    }
  }
}
