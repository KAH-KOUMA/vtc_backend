import 'dart:convert';
import 'package:http/http.dart';
import 'api_service.dart';
import '../utils/toast_utils.dart';

class AuthService {
  final ApiService _api = ApiService();

  Future<Map<String, dynamic>> login(String phone, String password) async {
    final response = await _api.postRequest('/auth/login', {
      'phone': phone,
      'password': password,
    }, null);

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Échec connexion : ${response.body}');
    }
  }

  Future<Map<String, dynamic>> register(String fullName, String phone, String password) async {
    final response = await _api.postRequest('/auth/register', {
      'fullName': fullName,
      'phone': phone,
      'password': password,
    }, null);

    if (response.statusCode == 201) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Échec inscription : ${response.body}');
    }
  }

  // Récupère le rôle de l'utilisateur
  Future<String> getUserRole(String token) async {
    final response = await _api.getRequest('/auth/me', token);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['role']; // 'client' ou 'driver'
    } else {
      throw Exception('Erreur rôle utilisateur : ${response.body}');
    }
  }
}
