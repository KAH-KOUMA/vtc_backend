import 'package:socket_io_client/socket_io_client.dart' as IO;

class SocketService {
  late IO.Socket socket;

  void connect() {
    socket = IO.io('http://localhost:3000', <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': false,
    });

    socket.connect();

    socket.onConnect((_) {
      print('Connecté au WebSocket');
    });

    socket.on('statusUpdated', (data) {
      print('Statut mis à jour : $data');
      // Ici tu peux déclencher un update d’écran
    });

    socket.onDisconnect((_) => print('Déconnecté du WebSocket'));
  }

  void disconnect() {
    socket.disconnect();
  }
}
