import 'dart:convert';
import 'package:http/http.dart' as http;
import 'secure_storage.dart';

class ApiService {
  final String baseUrl = 'http://localhost:3000/api';
  final SecureStorage _storage = SecureStorage();

  Future<Map<String, String>> _headers() async {
    final token = await _storage.getToken();
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  Future<List<dynamic>> getAvailableDrivers() async {
    final res = await http.get(Uri.parse('$baseUrl/drivers/available'), headers: await _headers());
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    } else {
      throw Exception('Erreur récupération chauffeurs');
    }
  }

  Future<void> createBooking(String driverId, String pickup, String dropoff) async {
    final res = await http.post(Uri.parse('$baseUrl/bookings'), 
      headers: await _headers(),
      body: jsonEncode({
        'driverId': driverId,
        'pickup': pickup,
        'dropoff': dropoff,
      }),
    );
    if (res.statusCode != 201) {
      throw Exception('Erreur création réservation');
    }
  }

  Future<List<dynamic>> getPendingRequests() async {
    final res = await http.get(Uri.parse('$baseUrl/driver/requests'), headers: await _headers());
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    } else {
      throw Exception('Erreur récupération demandes');
    }
  }

  Future<void> acceptRequest(String bookingId) async {
    final res = await http.post(Uri.parse('$baseUrl/driver/accept'), 
      headers: await _headers(),
      body: jsonEncode({'bookingId': bookingId}),
    );
    if (res.statusCode != 200) {
      throw Exception('Erreur acceptation');
    }
  }
}
