import 'package:flutter/material.dart'; // Importation de Material Design
import 'package:flutter_dotenv/flutter_dotenv.dart'; // Assure-toi d'avoir ajouté flutter_dotenv dans ton pubspec.yaml
import 'screens/login_screen.dart'; // Assure-toi que ce fichier existe bien

Future<void> main() async {
  // Initialisation nécessaire pour charger le .env AVANT le démarrage de l'app
  WidgetsFlutterBinding.ensureInitialized();

  // Chargement du fichier .env à la racine du projet
  await dotenv.load(fileName: ".env"); // Assure-toi que le fichier .env est bien à la racine du projet

  runApp(const MyApp());    // Lancement de l'application
}

class MyApp extends StatelessWidget { 
  const MyApp({super.key}); // Constructeur de MyApp
  // La clé est utilisée pour identifier de manière unique le widget dans l'arbre des widgets 

  @override
  Widget build(BuildContext context) { // Méthode build qui construit l'interface utilisateur
    return MaterialApp(
      title: 'VTC Frontend',
      theme: ThemeData(primarySwatch: Colors.blue),
      debugShowCheckedModeBanner: false,
      home: const LoginScreen(), // Ton écran d’accueil ici
    );
  }
}
