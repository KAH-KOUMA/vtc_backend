// routes/driverRoutes.js
const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middlewares/authMiddleware');

const {
  becomeDriver,
  getPendingRides,
  acceptRide
} = require('../controllers/driverController'); // Assure-toi que le chemin est correct

// Routes pour chauffeur
router.post('/become', authMiddleware, becomeDriver);
router.get('/rides', authMiddleware, getPendingRides);
router.post('/rides/:id/accept', authMiddleware, acceptRide);

module.exports = router;
