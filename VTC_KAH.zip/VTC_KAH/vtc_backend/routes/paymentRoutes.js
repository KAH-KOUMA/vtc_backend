const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middlewares/authMiddleware');
const { createPayment, getUserPayments } = require('../controllers/paymentController');

// Enregistrer un paiement
router.post('/', authMiddleware, createPayment);

// Voir ses paiements
router.get('/my', authMiddleware, getUserPayments);

module.exports = router;
