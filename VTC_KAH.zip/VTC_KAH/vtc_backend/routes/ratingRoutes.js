const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../middlewares/authMiddleware');
const { addRating, getUserRatings } = require('../controllers/ratingController');

// Ajouter une note
router.post('/', authMiddleware, addRating);

// Voir les évaluations d’un utilisateur
router.get('/:userId', authMiddleware, getUserRatings);

module.exports = router;
