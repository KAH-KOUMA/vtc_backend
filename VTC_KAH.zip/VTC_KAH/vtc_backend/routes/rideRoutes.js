const express = require('express');
const router = express.Router();

const { authMiddleware, clientMiddleware, chauffeurMiddleware } = require('../middlewares/authMiddleware');
const { updateRideStatus, getUserRides } = require('../controllers/rideController');
const Ride = require('../models/Ride');

// ✅ Créer une course (réservé aux clients)
router.post('/', authMiddleware, clientMiddleware, async (req, res) => {
  try {
    const { pickupLocation, dropoffLocation } = req.body;
    const ride = new Ride({
      clientId: req.user._id,
      pickupLocation,
      dropoffLocation
    });
    await ride.save();
    res.status(201).json({ message: 'Course créée', ride });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur', error });
  }
});

// ✅ Mettre à jour le statut d'une course (chauffeur ou admin)
router.patch('/:rideId/status', authMiddleware, updateRideStatus);

// ✅ Obtenir les courses d’un utilisateur connecté
router.get('/mes-courses', authMiddleware, getUserRides);

module.exports = router;
