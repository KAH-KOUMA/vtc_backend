const jwt = require('jsonwebtoken');
const User = require('../models/User');

// ✅ Middleware d'authentification
const authMiddleware = async (req, res, next) => {
  const token = req.header('Authorization')?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Accès refusé : pas de token' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-password');
    if (!user) return res.status(404).json({ message: 'Utilisateur non trouvé' });

    req.user = user;             // L'utilisateur complet
    req.userId = user._id;       // Facilité d'accès à son ID
    next();
  } catch (err) {
    res.status(400).json({ message: 'Token invalide' });
  }
};

// ✅ Middleware admin uniquement
const adminMiddleware = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Accès interdit : admin uniquement' });
  }
  next();
};

// ✅ Middleware chauffeur uniquement
const chauffeurMiddleware = (req, res, next) => {
  if (req.user.role !== 'chauffeur') {
    return res.status(403).json({ message: 'Accès interdit : chauffeur uniquement' });
  }
  next();
};

// ✅ Middleware client uniquement
const clientMiddleware = (req, res, next) => {
  if (req.user.role !== 'client') {
    return res.status(403).json({ message: 'Accès interdit : client uniquement' });
  }
  next();
};

module.exports = {
  authMiddleware,
  adminMiddleware,
  chauffeurMiddleware,
  clientMiddleware
};
