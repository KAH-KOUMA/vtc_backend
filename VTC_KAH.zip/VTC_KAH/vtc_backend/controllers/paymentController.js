const Payment = require('../models/payment');
const Ride = require('../models/Ride');

const createPayment = async (req, res) => {
  try {
    const { rideId, amount, method } = req.body;

    const ride = await Ride.findById(rideId);
    if (!ride) return res.status(404).json({ message: "Course introuvable" });

    const payment = new Payment({
      rideId,
      userId: req.userId,
      amount,
      method
    });

    await payment.save();
    res.status(201).json({ message: "Paiement enregistré", payment });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

const getUserPayments = async (req, res) => {
  try {
    const payments = await Payment.find({ userId: req.userId }).sort({ createdAt: -1 });
    res.status(200).json(payments);
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

module.exports = {
  createPayment,
  getUserPayments
};
