const Rating = require('../models/Rating');
const Ride = require('../models/Ride');

const addRating = async (req, res) => {
  try {
    const { rideId, targetId, note, commentaire } = req.body;

    // Vérifie si la course existe
    const ride = await Ride.findById(rideId);   
    if (!ride) return res.status(404).json({ message: 'Course non trouvée' });

    // Empêcher de noter 2 fois la même personne pour la même course
    const existing = await Rating.findOne({ rideId, reviewerId: req.userId, targetId });
    if (existing) return res.status(400).json({ message: 'Évaluation déjà soumise' });

    // Détermine si l'utilisateur est client ou chauffeur
    const role = ride.clientId.toString() === req.userId ? 'client' : 'chauffeur';

    const rating = new Rating({
      rideId,
      reviewerId: req.userId,
      targetId,
      note,
      commentaire,
      role
    });

    await rating.save();
    res.status(201).json({ message: "Évaluation enregistrée", rating });

  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

const getUserRatings = async (req, res) => {
  try {
    const ratings = await Rating.find({ targetId: req.params.userId }).sort({ createdAt: -1 });
    res.status(200).json(ratings);
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
};

module.exports = {
  addRating,
  getUserRatings
};
