const User = require('../models/User');
const Ride = require('../models/Ride');

const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.status(200).json({ total: users.length, users });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur', error });
  }
};

const getStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalRides = await Ride.countDocuments();
    const totalDrivers = await User.countDocuments({ role: 'chauffeur' });
    const totalClients = await User.countDocuments({ role: 'client' });

    const finishedRides = await Ride.find({ status: 'terminée' });
    const estimatedRevenue = finishedRides.length * 1000;

    res.status(200).json({
      totalUsers,
      totalClients,
      totalDrivers,
      totalRides,
      finishedRides: finishedRides.length,
      estimatedRevenue
    });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur', error });
  }
};

module.exports = {
  getAllUsers,
  getStats
};
