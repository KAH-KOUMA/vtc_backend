const Ride = require('../models/Ride');
const User = require('../models/User');
const { sendConsoleNotification, sendEmailSimulation } = require('../utils/notifier');

// 🔁 Mise à jour du statut d’une course
const updateRideStatus = async (req, res) => {
  try {
    const { rideId } = req.params;
    const { status } = req.body;

    // Vérifie que le statut est valide
    const allowedStatuses = ['en attente', 'en cours', 'terminée', 'annulée'];
    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({ message: 'Statut invalide' });
    }

    // Recherche de la course avec les utilisateurs associés
    const ride = await Ride.findById(rideId).populate('clientId driverId');
    if (!ride) return res.status(404).json({ message: 'Course non trouvée' });

    ride.status = status;
    await ride.save();

    const subject = `Mise à jour du statut de votre course`;
    const message = `La course ${ride._id} a été mise à jour au statut : ${status}`;

    // Notification client
    if (ride.clientId?.email) {
      sendConsoleNotification({ to: ride.clientId.email, subject, message });
      sendEmailSimulation({ to: ride.clientId.email, subject, message });
    }

    // Notification chauffeur
    if (ride.driverId?.email) {
      sendConsoleNotification({ to: ride.driverId.email, subject, message });
      sendEmailSimulation({ to: ride.driverId.email, subject, message });
    }

    res.status(200).json({ message: 'Statut mis à jour et notifications envoyées', ride });
  } catch (error) {
    console.error('Erreur updateRideStatus:', error);
    res.status(500).json({ message: 'Erreur serveur', error: error.message });
  }
};

// 📄 Récupérer les courses liées à l’utilisateur connecté
const getUserRides = async (req, res) => {
  try {
    const rides = await Ride.find({
      $or: [
        { clientId: req.userId },
        { driverId: req.userId }
      ]
    }).sort({ createdAt: -1 });

    res.status(200).json(rides);
  } catch (error) {
    console.error('Erreur getUserRides:', error);
    res.status(500).json({ message: 'Erreur serveur', error: error.message });
  }
};

module.exports = {
  updateRideStatus,
  getUserRides
};
