const User = require('../models/User');
const bcrypt = require('bcryptjs');
const generateToken = require('../utils/generateToken'); // ✅ Utilitaire pour générer le token

// Inscription d'un nouvel utilisateur
const register = async (req, res) => {
  const { fullName, phone, password } = req.body;

  // Vérification des champs obligatoires
  if (!fullName || !phone || !password) {
    return res.status(400).json({ message: 'Tous les champs sont requis' });
  }

  try {
    // Vérifier si l'utilisateur existe déjà
    const existingUser = await User.findOne({ phone });
    if (existingUser) {
      return res.status(400).json({ message: 'Utilisateur déjà existant' });
    }

    // Hachage du mot de passe
    const hashedPassword = await bcrypt.hash(password, 10);

    // Création du nouvel utilisateur
    const newUser = new User({ fullName, phone, password: hashedPassword });
    await newUser.save();

    // Génération du token après inscription
    const token = generateToken(newUser._id);

    // Réponse avec un message de succès et le token
    res.status(201).json({ message: 'Inscription réussie', token });

  } catch (err) {
    // Erreur serveur
    res.status(500).json({ message: 'Erreur serveur', error: err });
  }
};

// Connexion d'un utilisateur existant
const login = async (req, res) => {
  const { phone, password } = req.body;

  // Vérification des champs obligatoires
  if (!phone || !password) {
    return res.status(400).json({ message: 'Le téléphone et le mot de passe sont requis' });
  }

  try {
    // Recherche de l'utilisateur par téléphone
    const user = await User.findOne({ phone });
    if (!user) {
      return res.status(400).json({ message: 'Utilisateur introuvable' });
    }

    // Vérification du mot de passe
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ message: 'Mot de passe incorrect' });
    }

    // Génération du token à la connexion
    const token = generateToken(user._id);

    // Réponse avec un message de succès et le token
    res.status(200).json({ message: 'Connexion réussie', token });

  } catch (err) {
    // Erreur serveur
    res.status(500).json({ message: 'Erreur serveur', error: err });
  }
};

module.exports = { register, login };
