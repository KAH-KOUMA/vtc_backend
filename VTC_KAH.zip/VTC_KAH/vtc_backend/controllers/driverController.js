// controllers/driverController.js
const becomeDriver = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    user.role = 'chauffeur';
    await user.save();
    res.status(200).json({ message: 'Vous êtes maintenant chauffeur' });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur', error });
  }
};

const getPendingRides = async (req, res) => {
  try {
    const rides = await Ride.find({ status: 'en attente' });
    res.status(200).json(rides);
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur', error });
  }
};

const acceptRide = async (req, res) => {
  try {
    const ride = await Ride.findById(req.params.id);

    if (!ride) {
      return res.status(404).json({ message: 'Course non trouvée' });
    }

    if (ride.status !== 'en attente') {
      return res.status(400).json({ message: 'Course déjà prise ou terminée' });
    }

    ride.status = 'en cours';
    ride.driverId = req.userId;
    await ride.save();

    res.status(200).json({ message: 'Course acceptée', ride });
  } catch (error) {
    res.status(500).json({ message: 'Erreur serveur', error });
  }
};

module.exports = {
  becomeDriver,
  getPendingRides,
  acceptRide
};
