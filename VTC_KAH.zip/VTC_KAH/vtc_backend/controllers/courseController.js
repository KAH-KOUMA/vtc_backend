exports.updateStatus = async (req, res) => {
    const { courseId, newStatus } = req.body;
    try {
      const course = await Course.findByIdAndUpdate(courseId, { status: newStatus }, { new: true });
      const io = req.app.get('io');
  
      io.emit('statusUpdated', {
        courseId: course._id,
        newStatus: course.status
      });
  
      res.status(200).json(course);
    } catch (error) {
      res.status(500).json({ error: 'Erreur mise à jour du statut' });
    }
  };
  