// utils/generateToken.js
const jwt = require('jsonwebtoken');

/**
 * Génère un token JWT valide pendant 30 jours pour l'ID utilisateur donné
 * @param {string} id - ID MongoDB de l'utilisateur
 * @returns {string} Token JWT
 */
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });
};


module.exports = generateToken;
