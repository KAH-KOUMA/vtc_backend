// utils/notifier.js

const sendConsoleNotification = ({ to, subject, message }) => {
    console.log('\n🔔 Notification Console :');
    console.log(`À : ${to}`);
    console.log(`Sujet : ${subject}`);
    console.log(`Message : ${message}\n`);
  };
  
  const sendEmailSimulation = ({ to, subject, message }) => {
    console.log('\n📧 Simulation Email :');
    console.log(`To : ${to}`);
    console.log(`Subject : ${subject}`);
    console.log(`Body : ${message}\n`);
  };
  
  module.exports = {
    sendConsoleNotification,
    sendEmailSimulation,
  };
  