const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const morgan = require('morgan');
const http = require('http');
const { Server } = require('socket.io');
require('dotenv').config();

const app = express();

// Middleware de développement : logs
if (process.env.NODE_ENV === 'development') {
    app.use(morgan('dev'));
}

// Création du serveur HTTP et initialisation de Socket.io
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: '*', // À sécuriser pour la production
        methods: ['GET', 'POST']
    }
});

// Middleware globaux
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/rides', require('./routes/rideRoutes'));
app.use('/api/drivers', require('./routes/driverRoutes'));
app.use('/api/payments', require('./routes/paymentRoutes'));
app.use('/api/ratings', require('./routes/ratingRoutes'));
app.use('/api/admin', require('./routes/adminRoutes'));

// Route de test
app.get('/', (req, res) => {
    res.send('✅ VTC KAH en cours d\'exécution');
});

// Gestion globale des erreurs
const errorHandler = require('./middlewares/errorMiddleware');
app.use(errorHandler);

// Connexion MongoDB
mongoose.connect(process.env.MONGO_URI)
    .then(() => {
        console.log('✅ Connexion MongoDB réussie');
        server.listen(process.env.PORT || 3000, () => {
            console.log(`🚀 Serveur lancé sur le port ${process.env.PORT || 3000}`);
        });
    })
    .catch(err => {
        console.error('❌ Erreur MongoDB :', err);
    });

// ⚡️ Socket.IO - gestion des connexions
io.on('connection', (socket) => {
    console.log('🟢 Socket connecté :', socket.id);

    // Événements personnalisés ici si besoin...

    socket.on('disconnect', () => {
        console.log('🔴 Socket déconnecté :', socket.id);
    });
});

// Exposer Socket.IO dans l'app pour usage interne (ex: notifications)
app.set('io', io);
