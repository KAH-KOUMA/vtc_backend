const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  rideId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Ride',
    required: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  method: {
    type: String,
    enum: ['mobile money', 'carte', 'cash', 'autre'],
    required: true
  },
  status: {
    type: String,
    enum: ['en attente', 'réussi', 'échoué'],
    default: 'réussi'
  }
}, { timestamps: true });

module.exports = mongoose.model('Payment', paymentSchema);
